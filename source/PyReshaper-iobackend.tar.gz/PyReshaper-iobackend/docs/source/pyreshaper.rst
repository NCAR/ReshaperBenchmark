The PyReshaper Package
======================

.. automodule:: pyreshaper
    :members:
    :undoc-members:
    :show-inheritance:
    
Submodules
----------

.. toctree::
   :maxdepth: 2
   
   specification
   reshaper
   

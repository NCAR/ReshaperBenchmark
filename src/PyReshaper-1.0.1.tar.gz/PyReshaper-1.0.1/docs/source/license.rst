Product License
===============

.. include:: ../../LICENSE.rst

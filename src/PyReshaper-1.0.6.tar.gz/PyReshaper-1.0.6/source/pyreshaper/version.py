# Single place for version information
__version__ = '1.0.6'

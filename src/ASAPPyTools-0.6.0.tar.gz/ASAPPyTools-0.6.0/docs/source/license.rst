Product License
===============

.. include:: ../../LICENSE.txt

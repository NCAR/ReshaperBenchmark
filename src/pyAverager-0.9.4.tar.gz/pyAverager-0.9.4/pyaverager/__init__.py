# __init__.py

import PyAverager, specification, PreProc

__version__ = "0.9.4"

